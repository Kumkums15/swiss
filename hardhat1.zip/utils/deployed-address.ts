const deployedAddress = '0xc605c22d7Fc9d62460B06daF21242EBCb474eA77'

export default deployedAddress
